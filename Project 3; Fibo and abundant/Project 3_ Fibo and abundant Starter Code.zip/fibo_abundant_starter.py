choice = input("Input f|a|b (fibonacci, abundant or both): ")
